# OMAR'S PRIVATE BATCH — Vercel Deployment

## এই ZIP-এ কী আছে
- `index.html`: মূল অ্যাপ
- `plus.js`, `plus2.js`, `manifest.json`, `sw.js`, `logo.jpg`, `icon-192.png`, `icon-512.png`: আগের app assets (সব root-এ রাখা হয়েছে, মোবাইল থেকে GitHub upload সহজ করতে)
- `build.mjs`, `package.json`, `vercel.json`: Vercel build configuration
- `SUPABASE-DIAGNOSTIC.sql`: কোনো পরিবর্তন না করে Supabase schema, RPC, trigger ও RLS অবস্থা দেখার SQL

## Vercel-এ Deploy
1. ZIP extract করে ZIP-এর ভেতরের সব source file GitHub repository-র root-এ upload করুন। `dist/` folder upload করার দরকার নেই; Vercel build নিজে তৈরি করবে।
2. Vercel → Add New → Project → GitHub repository Import করুন।
3. Framework Preset `Other` রাখুন। Build Command `npm run build`, Output Directory `dist`।
4. Project → Settings → Environment Variables-এ যোগ করুন:
   - `VITE_SUPABASE_URL` = আপনার Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY` = Supabase-এর Publishable key (বা legacy anon public key)
5. Production, Preview এবং Development—যে environment-এ Deploy করবেন সেখানে variable যোগ করুন। তারপর Redeploy করুন।

**গুরুত্বপূর্ণ:** `sb_publishable_...` বা legacy `anon` key browser-এ ব্যবহারের জন্য public key। `service_role` বা `sb_secret_...` কখনো এখানে দেবেন না।

## Login পরীক্ষা
1. প্রথমে Admin email/password দিয়ে প্রবেশ পরীক্ষা করুন।
2. শিক্ষার্থী Login-এ নাম ও PIN দিন।
3. এখন RPC বা Auth ব্যর্থ হলে অ্যাপ প্রকৃত Supabase error দেখাবে।
4. নতুন account create হলে session না ফেরার বার্তা দেখালে Supabase Dashboard → Authentication → Providers → Email-এর Email Confirmation সেটিং পরীক্ষা করুন। পুরোনো account বা data মুছবেন না।

## Database নিরাপত্তা
`SUPABASE-DIAGNOSTIC.sql` কেবল SELECT/inspection চালায়; কোনো table, policy, function, user বা data পরিবর্তন করে না। এর ফলাফল পর্যালোচনা না করে পুরোনো migration আবার চালাবেন না।

## সীমাবদ্ধতা
এই সোর্স ZIP-এ মূল schema/bootstrap migration নেই এবং Supabase project-এ সরাসরি সংযোগ করে database/RLS/Auth configuration যাচাই করা হয়নি। তাই এখানে database পরিবর্তন বা live login success দাবি করা হচ্ছে না। Diagnostic SQL-এর ফলাফল দেখে প্রয়োজনীয় migration আলাদা করে তৈরি করতে হবে.
