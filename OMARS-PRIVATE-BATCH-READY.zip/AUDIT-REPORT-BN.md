# কোড অডিট রিপোর্ট — OMAR'S PRIVATE BATCH

## ZIP থেকে নিশ্চিতভাবে পাওয়া বিষয়
- মূল অ্যাপটি React 18 UMD + HTM + Supabase JS 2 UMD দিয়ে তৈরি একটি static HTML application।
- অ্যাপের মূল Supabase project URL এবং একটি `sb_publishable_...` key কোডে ছিল। Publishable key frontend-এ থাকার জন্যই; service-role/secret key পাওয়া যায়নি।
- PWA manifest, icons এবং service worker আছে।
- মূল UI-তে challenge, attendance, exams, marks, profiles/settings এবং plus modules রয়েছে।
- Frontend থেকে মোট 16টি RPC name ব্যবহৃত হয়েছে। প্রদত্ত চার SQL ফাইলে এর মধ্যে `student_names`, `set_universal_pin`, `class_days`, `challenge_marks`, `leaderboard` সংজ্ঞা পাওয়া যায়নি। এগুলো আগের database schema-তে থাকতে পারে; Supabase-এ যাচাই ছাড়া অনুপস্থিত বলা যাবে না।
- `SUPABASE-UPDATE-2.sql`-এ phone unique index তৈরি হয়। পুরোনো duplicate phone থাকলে এই statement ব্যর্থ হতে পারে। একই ফাইলে `handle_new_user()` function আছে, কিন্তু ওই ফাইলেই trigger creation statement নেই।
- `SUPABASE-UPDATE-3-PLUS.sql`-এর আগে `SUPABASE-UPDATE-4-ALL.sql` চালানোর নির্দেশ আছে; migration order গুরুত্বপূর্ণ।
- `SUPABASE-UPDATE.sql`-এ `ADD COLUMN IF NOT EXISTS` আছে; কিন্তু অন্য migration-এর সব statement একইভাবে duplicate-safe নয়।

## এই প্যাকেজে করা পরিবর্তন
- বাইরের ZIP-এর nested archive থেকে app files root-level deploy structure-এ সাজানো হয়েছে; GitHub mobile upload সহজ করতে assets-ও root-এ রাখা হয়েছে।
- Vercel-এর জন্য dependency-free build script যোগ হয়েছে; Vercel Environment Variables build-time-এ `index.html`-এ বসানো হয়।
- `VITE_SUPABASE_URL` এবং `VITE_SUPABASE_ANON_KEY` সমর্থন করা হয়েছে; `VITE_SUPABASE_PUBLISHABLE_KEY`-ও বিকল্প হিসেবে গ্রহণ করে।
- Frontend-এ কেবল public/publishable key গ্রহণ করা হয়; service-role/secret key build-এ প্রত্যাখ্যান করা হয়।
- Login screen এখন student-name RPC loading শেষ না হওয়া পর্যন্ত login action বন্ধ রাখে।
- `student_names`, `phone_taken`, `join_ok` এবং Authentication-এর আসল error message UI-তে দেখায়।
- নতুন account তৈরির পর Supabase session না দিলে email confirmation সংক্রান্ত ব্যাখ্যা দেখায়; একই account বারবার তৈরি করতে উৎসাহ দেয় না।
- PWA service-worker cache version `opb-v9` করা হয়েছে।
- কোনো database table, row, user, attendance, marks বা challenge data পরিবর্তন করা হয়নি।

## পরীক্ষার ফলাফল
- `npm run build`: সফল।
- Build output-এ index, plus scripts, manifest, service worker, logo এবং icons আছে: যাচাই করা হয়েছে।
- মূল inline JavaScript, `plus.js`, `plus2.js`, `build.mjs`: Node syntax check সফল।
- Environment variable দিয়ে test build: সফল; পরে default config-সহ build আবার চালানো হয়েছে।
- Supabase live login, Auth settings, RPC permissions, RLS, existing schema এবং real student data: এই পরিবেশ থেকে যাচাই করা যায়নি।

## পরবর্তী প্রয়োজনীয় যাচাই
`SUPABASE-DIAGNOSTIC.sql` চালিয়ে ফলাফল পর্যালোচনা করতে হবে। বিশেষ করে:
1. `student_names()` function আছে কি না এবং authenticated/anon role-এ execute করা যায় কি না।
2. `handle_new_user` trigger auth.users insert-এ profiles row তৈরি করছে কি না।
3. `profiles` select policy-তে student/admin login flow-এর প্রয়োজনীয় access আছে কি না।
4. Email provider confirmation configuration কী।
5. phone_number-এ duplicate data আছে কি না, unique index তৈরির আগে যাচাই করতে হবে।

Database diagnostic output ছাড়া destructive বা mutating SQL দেওয়া নিরাপদ নয়।
