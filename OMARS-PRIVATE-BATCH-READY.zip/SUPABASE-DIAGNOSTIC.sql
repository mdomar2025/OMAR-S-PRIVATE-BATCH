-- OMAR'S PRIVATE BATCH — READ-ONLY Supabase diagnostic
-- Supabase Dashboard > SQL Editor-এ পুরোটা চালান।
-- এই Script কেবল metadata পড়ে; কোনো data/schema/policy/function পরিবর্তন করে না.

-- 1) Required tables and row counts (counts are metadata queries, read-only)
select table_name
from information_schema.tables
where table_schema='public'
  and table_name in (
    'attendance','challenge_members','challenges','exams','marks',
    'profiles','settings','app_settings','classes','class_completions',
    'xp_transactions','announcements','posts','mcq_exams','mcq_questions',
    'mcq_answers','mcq_submissions','badges','student_badges','certificates',
    'notifications','notif_reads','settings_history'
  )
order by table_name;

-- 2) Important columns used by the application
select table_name, column_name, data_type, is_nullable, column_default
from information_schema.columns
where table_schema='public'
  and (
    (table_name='profiles' and column_name in ('id','name','student_code','phone_number','role','active'))
    or (table_name='challenges' and column_name in ('id','name','is_deleted','all_students'))
    or (table_name='settings' and column_name in ('key','value'))
  )
order by table_name, ordinal_position;

-- 3) RPCs called by the frontend and their presence/signatures
select n.nspname as schema_name, p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as arguments,
       pg_get_function_result(p.oid) as return_type,
       p.prosecdef as security_definer
from pg_proc p
join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public'
  and p.proname in (
    'admin_stats','award_badges','challenge_marks','class_days','complete_class',
    'delete_student','join_ok','leaderboard','mcq_board','mcq_start','mcq_submit',
    'my_streak','phone_taken','set_universal_pin','student_names','xp_leaderboard'
  )
order by p.proname;

-- 4) Auth -> profiles trigger status
select trigger_name, event_manipulation, action_timing, action_statement
from information_schema.triggers
where event_object_schema='auth'
  and event_object_table='users'
order by trigger_name;

-- 5) RLS enabled status
select c.relname as table_name, c.relrowsecurity as rls_enabled,
       c.relforcerowsecurity as force_rls
from pg_class c
join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r'
  and c.relname in (
    'attendance','challenge_members','challenges','exams','marks',
    'profiles','settings','app_settings','classes','class_completions',
    'xp_transactions','announcements','posts','mcq_exams','mcq_questions',
    'mcq_answers','mcq_submissions','badges','student_badges','certificates',
    'notifications','notif_reads','settings_history'
  )
order by c.relname;

-- 6) Policies on the core tables
select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
from pg_policies
where schemaname='public'
  and tablename in ('profiles','settings','attendance','challenge_members','challenges','exams','marks')
order by tablename, policyname;

-- 7) Auth email confirmation setting is not exposed as a SQL setting.
-- Check in Dashboard > Authentication > Providers > Email.
