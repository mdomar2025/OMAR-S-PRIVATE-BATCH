-- OMAR'S PRIVATE BATCH — Plus Migration (শুধু নতুন যোগ করে; পুরোনো টেবিল/ডেটা ছোঁয় না)
-- আগে Supabase Dashboard > Database > Backups থেকে Backup নিন। তারপর পুরোটা একবার Run করুন।
-- Rollback (দরকার হলে): drop function if exists complete_class(uuid), xp_leaderboard(); drop table if exists class_completions, xp_transactions, classes, announcements, app_settings cascade;
create table if not exists app_settings(key text primary key, value jsonb not null default '{}', updated_at timestamptz default now());
insert into app_settings(key,value) values
('features','{"classes":true,"xp":true,"announcements":true}'),
('levels','[{"n":"Starter","xp":0},{"n":"Learner","xp":100},{"n":"Achiever","xp":300},{"n":"Champion","xp":700},{"n":"Legend","xp":1500}]') on conflict(key) do nothing;
create table if not exists classes(id uuid primary key default gen_random_uuid(), title text not null, subject text, description text, class_date date default current_date, youtube_url text, xp int not null default 10, published boolean not null default false, created_at timestamptz default now());
create table if not exists class_completions(class_id uuid references classes(id) on delete cascade, student_id uuid references profiles(id) on delete cascade, completed_at timestamptz default now(), primary key(class_id,student_id));
create table if not exists xp_transactions(id uuid primary key default gen_random_uuid(), student_id uuid references profiles(id) on delete cascade, amount int not null, reason text, ref_key text unique, created_at timestamptz default now());
create table if not exists announcements(id uuid primary key default gen_random_uuid(), title text not null, body text, pinned boolean default false, expires_on date, created_at timestamptz default now());
create index if not exists xp_student_idx on xp_transactions(student_id);
alter table app_settings enable row level security; alter table classes enable row level security; alter table class_completions enable row level security; alter table xp_transactions enable row level security; alter table announcements enable row level security;
drop policy if exists p_set_r on app_settings; create policy p_set_r on app_settings for select to authenticated using(true);
drop policy if exists p_set_w on app_settings; create policy p_set_w on app_settings for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists p_cls_r on classes; create policy p_cls_r on classes for select to authenticated using(published or is_admin());
drop policy if exists p_cls_w on classes; create policy p_cls_w on classes for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists p_cc_r on class_completions; create policy p_cc_r on class_completions for select to authenticated using(student_id=auth.uid() or is_admin());
drop policy if exists p_xp_r on xp_transactions; create policy p_xp_r on xp_transactions for select to authenticated using(student_id=auth.uid() or is_admin());
drop policy if exists p_an_r on announcements; create policy p_an_r on announcements for select to authenticated using(expires_on is null or expires_on>=current_date);
drop policy if exists p_an_w on announcements; create policy p_an_w on announcements for all to authenticated using(is_admin()) with check(is_admin());
-- ক্লাস Complete + XP: সার্ভারে, ডুপ্লিকেট হলে দ্বিতীয়বার XP নেই
create or replace function complete_class(cid uuid) returns boolean language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); x int; ins int;
begin
 select xp into x from classes where id=cid and published; if not found then raise exception 'class not available'; end if;
 insert into class_completions(class_id,student_id) values(cid,u) on conflict do nothing; get diagnostics ins=row_count;
 if ins=0 then return false; end if;
 insert into xp_transactions(student_id,amount,reason,ref_key) values(u,x,'class','class:'||cid||':'||u) on conflict(ref_key) do nothing;
 return true; end$$;
grant execute on function complete_class(uuid) to authenticated;
-- টোটাল XP লিডারবোর্ড (টাই হলে নাম অনুযায়ী)
create or replace function xp_leaderboard() returns table(student_id uuid,name text,xp bigint) language sql security definer stable set search_path=public as $$
 select p.id,p.name,coalesce(sum(t.amount),0)::bigint x from profiles p left join xp_transactions t on t.student_id=p.id where p.role='student' and p.active group by p.id,p.name order by x desc,p.name limit 100$$;
grant execute on function xp_leaderboard() to authenticated;
