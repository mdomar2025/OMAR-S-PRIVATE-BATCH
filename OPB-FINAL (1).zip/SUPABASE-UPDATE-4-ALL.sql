-- OMAR'S PRIVATE BATCH — Part 4 (আগে SUPABASE-UPDATE-3-PLUS.sql চালানো থাকতে হবে। শুধু নতুন যোগ করে)
-- Rollback: drop table if exists posts,post_likes,post_comments,post_reports,mcq_exams,mcq_questions,mcq_answers,mcq_submissions,badges,student_badges,certificates,notifications,notif_reads,settings_history cascade;
create table if not exists posts(id uuid primary key default gen_random_uuid(),author_id uuid references profiles(id) on delete cascade default auth.uid(),author_name text,body text not null check(length(body)<=1000),pinned boolean default false,created_at timestamptz default now());
create table if not exists post_likes(post_id uuid references posts(id) on delete cascade,user_id uuid references profiles(id) on delete cascade default auth.uid(),primary key(post_id,user_id));
create table if not exists post_comments(id uuid primary key default gen_random_uuid(),post_id uuid references posts(id) on delete cascade,author_id uuid references profiles(id) on delete cascade default auth.uid(),author_name text,body text not null check(length(body)<=500),created_at timestamptz default now());
create table if not exists post_reports(post_id uuid references posts(id) on delete cascade,user_id uuid references profiles(id) on delete cascade default auth.uid(),created_at timestamptz default now(),primary key(post_id,user_id));
create table if not exists mcq_exams(id uuid primary key default gen_random_uuid(),title text not null,kind text not null default 'mcq' check(kind in('mcq','comp')),minutes int not null default 10,neg numeric not null default 0,shuffle boolean not null default true,retake boolean not null default false,published boolean not null default false,starts_at timestamptz,ends_at timestamptz,created_at timestamptz default now());
create table if not exists mcq_questions(id uuid primary key default gen_random_uuid(),exam_id uuid references mcq_exams(id) on delete cascade,q text not null,opts jsonb not null,marks int not null default 1,expl text,pos bigserial);
create table if not exists mcq_answers(question_id uuid primary key references mcq_questions(id) on delete cascade,correct int not null);
create table if not exists mcq_submissions(id uuid primary key default gen_random_uuid(),exam_id uuid references mcq_exams(id) on delete cascade,student_id uuid references profiles(id) on delete cascade,score numeric,total numeric,started_at timestamptz default now(),submitted_at timestamptz,answers jsonb);
create table if not exists badges(id uuid primary key default gen_random_uuid(),name text not null,icon text default '⭐',rule text not null check(rule in('xp','streak','classes','mcq')),threshold int not null,xp int not null default 0,active boolean not null default true);
create table if not exists student_badges(student_id uuid references profiles(id) on delete cascade,badge_id uuid references badges(id) on delete cascade,earned_at timestamptz default now(),primary key(student_id,badge_id));
create table if not exists certificates(id uuid primary key default gen_random_uuid(),student_id uuid references profiles(id) on delete cascade,title text not null,issued_on date default current_date,code text unique default substr(md5(random()::text),1,8));
create table if not exists notifications(id uuid primary key default gen_random_uuid(),student_id uuid references profiles(id) on delete cascade,title text not null,body text,created_at timestamptz default now());
create table if not exists notif_reads(notif_id uuid references notifications(id) on delete cascade,user_id uuid default auth.uid(),primary key(notif_id,user_id));
create table if not exists settings_history(id bigserial primary key,key text,old jsonb,new jsonb,at timestamptz default now(),by uuid default auth.uid());
insert into badges(name,icon,rule,threshold,xp) select * from (values('First Step','👣','classes',1,5),('7 Days Warrior','🔥','streak',7,20),('XP 500','🏆','xp',500,0),('Quiz Master','🧠','mcq',5,20)) v where not exists(select 1 from badges);
do $$ declare t text; begin foreach t in array array['posts','post_likes','post_comments','post_reports','mcq_exams','mcq_questions','mcq_answers','mcq_submissions','badges','student_badges','certificates','notifications','notif_reads','settings_history'] loop execute format('alter table %I enable row level security',t); end loop; end$$;
drop policy if exists c1 on posts; create policy c1 on posts for select to authenticated using(true);
drop policy if exists c2 on posts; create policy c2 on posts for insert to authenticated with check(author_id=auth.uid());
drop policy if exists c3 on posts; create policy c3 on posts for delete to authenticated using(author_id=auth.uid() or is_admin());
drop policy if exists c4 on posts; create policy c4 on posts for update to authenticated using(is_admin()) with check(is_admin());
drop policy if exists l1 on post_likes; create policy l1 on post_likes for select to authenticated using(true);
drop policy if exists l2 on post_likes; create policy l2 on post_likes for insert to authenticated with check(user_id=auth.uid());
drop policy if exists l3 on post_likes; create policy l3 on post_likes for delete to authenticated using(user_id=auth.uid());
drop policy if exists m1 on post_comments; create policy m1 on post_comments for select to authenticated using(true);
drop policy if exists m2 on post_comments; create policy m2 on post_comments for insert to authenticated with check(author_id=auth.uid());
drop policy if exists m3 on post_comments; create policy m3 on post_comments for delete to authenticated using(author_id=auth.uid() or is_admin());
drop policy if exists r1 on post_reports; create policy r1 on post_reports for insert to authenticated with check(user_id=auth.uid());
drop policy if exists r2 on post_reports; create policy r2 on post_reports for select to authenticated using(is_admin());
drop policy if exists e1 on mcq_exams; create policy e1 on mcq_exams for select to authenticated using(published or is_admin());
drop policy if exists e2 on mcq_exams; create policy e2 on mcq_exams for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists q1 on mcq_questions; create policy q1 on mcq_questions for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists a1 on mcq_answers; create policy a1 on mcq_answers for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists s1 on mcq_submissions; create policy s1 on mcq_submissions for select to authenticated using(student_id=auth.uid() or is_admin());
drop policy if exists b1 on badges; create policy b1 on badges for select to authenticated using(true);
drop policy if exists b2 on badges; create policy b2 on badges for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists sb1 on student_badges; create policy sb1 on student_badges for select to authenticated using(student_id=auth.uid() or is_admin());
drop policy if exists ce1 on certificates; create policy ce1 on certificates for select to authenticated using(student_id=auth.uid() or is_admin());
drop policy if exists ce2 on certificates; create policy ce2 on certificates for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists n1 on notifications; create policy n1 on notifications for select to authenticated using(student_id is null or student_id=auth.uid() or is_admin());
drop policy if exists n2 on notifications; create policy n2 on notifications for all to authenticated using(is_admin()) with check(is_admin());
drop policy if exists nr1 on notif_reads; create policy nr1 on notif_reads for select to authenticated using(user_id=auth.uid());
drop policy if exists nr2 on notif_reads; create policy nr2 on notif_reads for insert to authenticated with check(user_id=auth.uid());
drop policy if exists h1 on settings_history; create policy h1 on settings_history for select to authenticated using(is_admin());
create or replace function set_author() returns trigger language plpgsql security definer set search_path=public as $$ begin new.author_name:=(select name from profiles where id=auth.uid());
if tg_table_name='posts' and exists(select 1 from posts where author_id=auth.uid() and created_at>now()-interval '15 seconds') then raise exception 'একটু পরে আবার পোস্ট করুন'; end if; return new; end$$;
drop trigger if exists t_post on posts; create trigger t_post before insert on posts for each row execute function set_author();
drop trigger if exists t_com on post_comments; create trigger t_com before insert on post_comments for each row execute function set_author();
create or replace function log_setting() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into settings_history(key,old,new) values(new.key,case when tg_op='UPDATE' then old.value end,new.value); return new; end$$;
drop trigger if exists t_set on app_settings; create trigger t_set after insert or update on app_settings for each row execute function log_setting();
create or replace function mcq_start(eid uuid) returns jsonb language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); e mcq_exams; s mcq_submissions;
begin select * into e from mcq_exams where id=eid and published; if not found then raise exception 'পরীক্ষা পাওয়া যায়নি'; end if;
if (e.starts_at is not null and now()<e.starts_at) or (e.ends_at is not null and now()>e.ends_at) then raise exception 'এখন পরীক্ষা চালু নেই'; end if;
select * into s from mcq_submissions where exam_id=eid and student_id=u and submitted_at is null and started_at+make_interval(mins=>e.minutes)>now() order by started_at desc limit 1;
if not found then
 if not e.retake and exists(select 1 from mcq_submissions where exam_id=eid and student_id=u and submitted_at is not null) then raise exception 'আপনি আগেই পরীক্ষা দিয়েছেন'; end if;
 insert into mcq_submissions(exam_id,student_id) values(eid,u) returning * into s; end if;
return jsonb_build_object('sub_id',s.id,'secs',greatest(5,extract(epoch from (s.started_at+make_interval(mins=>e.minutes)-now()))::int),'shuffle',e.shuffle,
 'questions',(select coalesce(jsonb_agg(jsonb_build_object('id',id,'q',q,'opts',opts,'marks',marks) order by pos),'[]'::jsonb) from mcq_questions where exam_id=eid)); end$$;
create or replace function mcq_submit(sid uuid,ans jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); s mcq_submissions; e mcq_exams; sc numeric:=0; tot numeric; r record;
begin select * into s from mcq_submissions where id=sid and student_id=u and submitted_at is null; if not found then raise exception 'জমা দেওয়া হয়ে গেছে'; end if;
select * into e from mcq_exams where id=s.exam_id; select coalesce(sum(marks),0) into tot from mcq_questions where exam_id=s.exam_id;
if now()<=s.started_at+make_interval(mins=>e.minutes)+interval '1 minute' then
 for r in select q.id,q.marks,a.correct from mcq_questions q join mcq_answers a on a.question_id=q.id where q.exam_id=s.exam_id loop
  if ans->>(r.id::text) is not null then if (ans->>(r.id::text))::int=r.correct then sc:=sc+r.marks; else sc:=sc-e.neg; end if; end if; end loop; end if;
sc:=greatest(sc,0); update mcq_submissions set score=sc,total=tot,submitted_at=now(),answers=ans where id=sid;
if round(sc)>0 then insert into xp_transactions(student_id,amount,reason,ref_key) values(u,round(sc)::int,e.kind,'mcq:'||sid) on conflict do nothing; end if;
return jsonb_build_object('score',sc,'total',tot); end$$;
create or replace function mcq_board(eid uuid) returns table(student_id uuid,name text,score numeric,total numeric) language sql security definer stable set search_path=public as $$
select p.id,p.name,max(s.score),max(s.total) from mcq_submissions s join profiles p on p.id=s.student_id where s.exam_id=eid and s.submitted_at is not null and (is_admin() or exists(select 1 from mcq_exams e where e.id=eid and e.published)) group by p.id,p.name order by max(s.score) desc,p.name limit 100$$;
create or replace function streak_of(u uuid) returns table(cur int,longest int,total int) language sql stable security definer set search_path=public as $$
with d as(select distinct (created_at at time zone 'Asia/Dhaka')::date day from xp_transactions where student_id=u union select day from attendance where student_id=u),
g as(select day,day-(row_number() over(order by day))::int grp from d),s as(select grp,count(*) n,max(day) last from g group by grp)
select coalesce((select n from s where last>=(now() at time zone 'Asia/Dhaka')::date-1 order by last desc limit 1),0)::int,coalesce((select max(n) from s),0)::int,(select count(*) from d)::int$$;
revoke execute on function streak_of(uuid) from public,anon,authenticated;
create or replace function my_streak() returns table(cur int,longest int,total int) language sql stable security definer set search_path=public as $$select * from streak_of(auth.uid())$$;
create or replace function award_badges() returns int language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); b record; v bigint; n int:=0; st record;
begin select * into st from streak_of(u);
for b in select * from badges where active and id not in(select badge_id from student_badges where student_id=u) loop
 v:=case b.rule when 'xp' then(select coalesce(sum(amount),0) from xp_transactions where student_id=u) when 'streak' then st.longest when 'classes' then(select count(*) from class_completions where student_id=u) else(select count(*) from mcq_submissions where student_id=u and submitted_at is not null) end;
 if v>=b.threshold then insert into student_badges(student_id,badge_id) values(u,b.id) on conflict do nothing;
  if b.xp>0 then insert into xp_transactions(student_id,amount,reason,ref_key) values(u,b.xp,'badge','badge:'||b.id||':'||u) on conflict do nothing; end if; n:=n+1; end if; end loop; return n; end$$;
create or replace function admin_stats() returns jsonb language plpgsql security definer stable set search_path=public as $$
begin if not is_admin() then raise exception 'not allowed'; end if;
return jsonb_build_object('students',(select count(*) from profiles where role='student'),'active',(select count(*) from profiles where role='student' and active),'classes',(select count(*) from classes),'completions',(select count(*) from class_completions),'mcq',(select count(*) from mcq_submissions where submitted_at is not null),'xp',(select coalesce(sum(amount),0) from xp_transactions),'posts',(select count(*) from posts),'reports',(select count(*) from post_reports),
'today',(select count(*) from(select student_id from xp_transactions where (created_at at time zone 'Asia/Dhaka')::date=(now() at time zone 'Asia/Dhaka')::date union select student_id from attendance where day=(now() at time zone 'Asia/Dhaka')::date) t)); end$$;
grant execute on function mcq_start(uuid),mcq_submit(uuid,jsonb),mcq_board(uuid),my_streak(),award_badges(),admin_stats() to authenticated;
