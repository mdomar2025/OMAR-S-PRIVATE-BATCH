-- Supabase > SQL Editor এ পুরোটা পেস্ট করে Run করুন

-- ১) একই মোবাইল নম্বরে একটির বেশি অ্যাকাউন্ট নয়
create unique index if not exists profiles_phone_uq on profiles(phone_number) where phone_number is not null and phone_number<>'';

create or replace function phone_taken(p text) returns boolean language sql security definer stable set search_path=public as $$select exists(select 1 from profiles where phone_number=p)$$;
grant execute on function phone_taken(text) to anon,authenticated;

create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
insert into profiles(id,name,student_code,phone_number) values(new.id,coalesce(new.raw_user_meta_data->>'name','Admin'),new.raw_user_meta_data->>'student_code',nullif(regexp_replace(coalesce(new.raw_user_meta_data->>'phone_number',''),'\D','','g'),''));
return new;
end$$;

-- ২) অ্যাডমিন শিক্ষার্থীকে চিরতরে মুছতে পারবে (হাজিরা ও নম্বরসহ)
create or replace function delete_student(sid uuid) returns void language plpgsql security definer set search_path=public as $$
begin
if not is_admin() then raise exception 'not allowed'; end if;
if not exists(select 1 from profiles where id=sid and role='student') then raise exception 'not a student'; end if;
delete from auth.users where id=sid;
end$$;
grant execute on function delete_student(uuid) to authenticated;
