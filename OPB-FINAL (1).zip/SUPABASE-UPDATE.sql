-- Run once in Supabase Dashboard > SQL Editor > New query.
-- Safe archive flag: existing attendance, exams, marks and membership rows remain untouched.
ALTER TABLE public.challenges
ADD COLUMN IF NOT EXISTS is_deleted boolean NOT NULL DEFAULT false;

-- Student mobile / WhatsApp contact number.
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS phone_number text;

-- Existing challenges remain visible unless explicitly archived.
UPDATE public.challenges
SET is_deleted = false
WHERE is_deleted IS NULL;

-- Remove the old 30-student limit while keeping the shared PIN check.
CREATE OR REPLACE FUNCTION public.join_ok(p text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT COALESCE(
    (SELECT value FROM public.settings WHERE key = 'pin') = p,
    false
  );
$function$;
